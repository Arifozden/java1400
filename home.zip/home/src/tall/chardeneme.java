package tall;

import java.net.StandardSocketOptions;

public class chardeneme {
    public static void main(String[] args) {
        char karakter = 117;
        char karakter2 = 'u';
        System.out.println(karakter2);

        boolean mantik = true;
        System.out.println(mantik);
    }
}
