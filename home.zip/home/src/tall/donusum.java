package tall;

public class donusum {
    public static void main(String[] args) {
        double x=81.99;
        int y=(int)x;


        System.out.println(y);

    }
}
