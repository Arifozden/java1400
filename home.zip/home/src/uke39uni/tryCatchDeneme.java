package uke39uni;
/*
import javax.swing.*;

public class tryCatchDeneme {
    public static void main(String[] args) {
        String girSayi1= JOptionPane.showInputDialog("Bir sayi girin");
        String girSayi2= JOptionPane.showInputDialog("Bir sayi daha girin");

        int sayi1=Integer.parseInt(girSayi1);
        int sayi2=Integer.parseInt(girSayi2);
        int sonuc;
        try {
            sonuc=sayi1/sayi2;
            System.out.println(sayi1/sayi2);
        }
        catch (Exception e){

            System.out.println(e);
            System.out.println("Hatali giris");
        }
        System.out.println("Devam etti");
    }

}
*/