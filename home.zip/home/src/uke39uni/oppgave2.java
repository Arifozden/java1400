package uke39uni;

public class oppgave2 {
    public static void main(String[] args) {
        double tall1=2.2;
        double tall2=3.3;
        double tall3=4.4;
        double tall4=tall1+tall2+tall3;
        System.out.println(tall4);
    }
}
