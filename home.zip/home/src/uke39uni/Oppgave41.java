package uke39uni;

public class Oppgave41 {
    public static void main(String[] args) {
        String navn="Per Olsen";
        int alder=36;
        int fodt= 2022- alder;
        int framtid= 2053-fodt;
        System.out.println(navn+" er i dag "+alder+" år. Han er født i "+fodt+". I 2053 er han "+framtid+" år og da vil han være pensjonist." );
    }


}
