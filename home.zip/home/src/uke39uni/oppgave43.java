package uke39uni;

public class oppgave43 {
    public static void main(String[] args) {
        double lengden=40;
        double bredden=20;
        double arealet=lengden*bredden;
        System.out.println("Et rektangel med bredde "+bredden+" cm og lengde "+lengden+" cm har et areal på "+arealet+" cm^2.");
    }
}
