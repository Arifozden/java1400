package uke39uni;

import javax.swing.*;

public class oppgave3 {
    public static void main(String[] args) {
        double tall1=2.2;
        double tall2=3.3;
        double tall3=4.4;
        double tall4=(tall1+tall2+tall3)/3;
        System.out.println(tall4);
        JOptionPane.showMessageDialog(null,tall4);
    }
}
