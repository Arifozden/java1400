package uke39uni;

public class oppgave42 {
    public static void main(String[] args) {
        int antall0=0;
        int antall1=antall0+2;
        int antall2=antall1+2;
        int antall3=antall2+2;
        int antall4=antall3+2;
        int antall5=antall4+2;
        System.out.println(antall0);
        System.out.println(antall1);
        System.out.println(antall2);
        System.out.println(antall3);
        System.out.println(antall4);
        System.out.println(antall5);
    }
}
