public class Araba {
    String renk;
    String model;
    Double motor;
    int yil;
    public  void main(String[] args) {


        renk="yellow ";
        model="renault ";
        motor=1.6 ;
        yil=2016 ;

        System.out.println("Renk: "+renk+"Model: "+model+"Motor: "+motor+"yil: "+yil);
    }
}
